import { NgModule } from '@angular/core';



@NgModule({
  declarations: [],
  imports: [
  ]
})
export class ProductVariantsFeatureModule { }
